
/**
 * GzipClient Class
 * 
 * CPSC 441
 * Assignment 1
 * 
 *
 */


import java.util.logging.*;


public class GzipClient {

	private static final Logger logger = Logger.getLogger("GzipClient"); // global logger

	/**
	 * Constructor to initialize the class.
	 * 
	 * @param serverName	remote server name
	 * @param serverPort	remote server port number
	 * @param bufferSize	buffer size used for read/write
	 */
	public GzipClient(String serverName, int serverPort, int bufferSize);

	
	/**
	 * Compress the specified file via the remote server.
	 * 
	 * @param inName		name of the input file to be compressed
	 * @param outName		name of the output compressed file
	 */
	public void gzip(String inName, String outName);
	
}
